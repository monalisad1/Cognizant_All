package com.library.dao;

public class BookRepository {
	public void update() {
		System.out.println("Updating Book....");
	}
}
