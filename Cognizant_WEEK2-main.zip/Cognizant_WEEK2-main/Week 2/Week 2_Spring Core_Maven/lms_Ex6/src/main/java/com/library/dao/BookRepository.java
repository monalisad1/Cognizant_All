package com.library.dao;


import org.springframework.stereotype.Repository;


@Repository
public class BookRepository {
	public void update() {
		System.out.println("Updating Book....");
	}
}
